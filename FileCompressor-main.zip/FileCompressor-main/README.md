# FileCompressor
File Compressor using Huffman or LZW Algorithm with GUI Design (in Java Language)
